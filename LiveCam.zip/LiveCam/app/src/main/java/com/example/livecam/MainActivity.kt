package com.example.livecam

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.SurfaceHolder
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.library.rtmp.RtmpCamera2
import com.pedro.library.view.OpenGlView

class MainActivity : AppCompatActivity(), ConnectChecker {

    private lateinit var camera: RtmpCamera2
    private lateinit var btnLive: Button
    private lateinit var etUrl: EditText
    private var surfaceReady = false

    private val permissions = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) startPreview() else toast("الصلاحيات مطلوبة")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val glView = findViewById<OpenGlView>(R.id.glView)
        btnLive = findViewById(R.id.btnLive)
        etUrl = findViewById(R.id.etUrl)
        camera = RtmpCamera2(glView, this)

        glView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                surfaceReady = true
                if (hasPermissions()) startPreview() else permLauncher.launch(permissions)
            }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
                if (surfaceReady && hasPermissions()) startPreview()
            }
            override fun surfaceDestroyed(holder: SurfaceHolder) {
                surfaceReady = false
                if (camera.isStreaming) camera.stopStream()
                camera.stopPreview()
            }
        })

        btnLive.setOnClickListener {
            if (!camera.isStreaming) {
                val url = etUrl.text.toString().trim()
                if (url.isEmpty()) { toast("أدخل رابط RTMP"); return@setOnClickListener }
                if (camera.prepareAudio() && camera.prepareVideo(1280, 720, 30, 2500 * 1024)) {
                    camera.startStream(url)
                    btnLive.text = "إيقاف"
                } else toast("الجهاز لا يدعم الإعدادات")
            } else {
                camera.stopStream()
                btnLive.text = "بدء البث"
            }
        }

        findViewById<Button>(R.id.btnFlip).setOnClickListener { camera.switchCamera() }
    }

    private fun hasPermissions() = permissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startPreview() {
        if (surfaceReady && !camera.isOnPreview) camera.startPreview()
    }

    private fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onConnectionStarted(url: String) {}
    override fun onConnectionSuccess() = toast("متصل ✓")
    override fun onConnectionFailed(reason: String) {
        runOnUiThread {
            camera.stopStream()
            btnLive.text = "بدء البث"
        }
        toast("فشل الاتصال: $reason")
    }
    override fun onNewBitrate(bitrate: Long) {}
    override fun onDisconnect() {
        runOnUiThread { btnLive.text = "بدء البث" }
        toast("انقطع البث")
    }
    override fun onAuthError() = toast("خطأ مصادقة")
    override fun onAuthSuccess() {}
}
